window.game = ''
window.server=''
window.launcher = ''

const delay = ms => new Promise(res => setTimeout(res, ms));
window.parteCriar =function(){
    document.getElementsByClassName("flq-preloader")[0].classList.remove("flq-preloader-hide")
    setTimeout(function() {
        document.getElementsByClassName("content-wrap")[0].innerHTML=""
        document.getElementsByClassName("flq-swiper-wrapper")[0].innerHTML=""
        document.querySelector(".loader").classList.remove("loader-hide")
        document.querySelector(".status_text").classList.remove("status_text-hide")
        document.getElementsByClassName("flq-preloader")[0].classList.add("flq-preloader-hide")
    }, 1500);

}

document.addEventListener("DOMContentLoaded", function(){
    if (document.cookie.indexOf('token=') == -1){
        document.getElementById("user-logo").style.display='none'
        window.loggedin=false
    }else{
        window.loggedin=true
        document.getElementById("botao-entrar").classList.remove("d-md-flex")
        document.getElementById("botao-entrar").style.display='none'
    }
});
  

window.logar =function(){
        var login=$(".form-do-login1")[0].value;
        var senha=$(".form-do-login2")[0].value;
        const log_btn=$("#botn-logar")[0]

        var xhr = new XMLHttpRequest();
        var url = "     /auth/login";
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.onreadystatechange = function () {
            var json = JSON.parse(xhr.responseText);
            if (xhr.status === 200) {
                if (json.success!=true){
                    log_btn.disabled=false
                    $(".form-do-login1")[0].style.borderColor='red'
                    return $(".form-do-login2")[0].style.borderColor='red'
                    //err_obj.innerHTML=`\n                    Error: Usuário não existe/Sem assinatura válida\n                `
                    //return err_obj.classList.remove("error--hidden")
                }
                window.location.href = "/painel"
            }else{
                log_btn.disabled=false
                $(".form-do-login1")[0].style.borderColor='red'
                return $(".form-do-login2")[0].style.borderColor='red'
            }
        };
        var data = JSON.stringify({"username": login, "password": senha});
        xhr.send(data);

        console.log(login,senha)

}

window.checkAll=function(){
    if (!loggedin){
        window.location.href='/'
    }
}


const socket = io.connect();
socket.on('connect', function (msg) {
    console.log("Conectado ao Servidor")
});


socket.on("del", function (msg) {
    if (msg != true) {
        document.cookie = 'token=; max-age=0;';
        window.location.href = '/'
    }
})


socket.on('criado', function (msg) {
    myNode.innerHTML = '';
    document.querySelector(".infoVM").classList.remove("infoVM--hidden")
    document.getElementById("main-header").innerHTML = ''
    document.getElementById("ip-add").value = msg.ip
    document.getElementById("pass").value = msg.password
})

socket.on("reconnect", function (msg) {
    if (msg != "NADA") {
        myNode.innerHTML = '';
        document.querySelector(".loader").classList.remove("loader--hidden")
        document.getElementById("status_text").innerHTML = msg
    }
})


socket.on("private", function (msg) {
    window.location.href = "/painel"
    console.log(socket)
})

socket.on("cookie", function (msg) {
    console.log("Cookie> ", msg)
    document.cookie = `info=${msg};`
})

socket.on("error", function (msg) {
    if (msg.code == 2828) {
        alert("Inicie outro jogo/tente mais tarde.")
    }
    window.location.href = "/"

})

socket.on("fisica2", function (msg) {
    document.getElementById("status_text").innerHTML = `Carregando sua VM Física...`
    socket.emit("vmCommand", { "event": "CreateVM" })
})

socket.on("fila", function (msg) {
    document.getElementById("status_text").innerHTML = `Posição na fila: ${msg.position}`
    setTimeout(1500)
    socket.emit("vmCommand", { "event": "List" })
})

socket.on("fisica2-error", async function (msg) {
    alert(msg)
    window.location.href = '/'
})

socket.on("RecCreated", async function (msg) {
    parteCriar()
    setTimeout(function(){
        if (msg.fisica){
            $("#formdasenha-fisica")[0].value=msg.password
            $("#formdoip-fisica")[0].value = msg.ip
            $("#entrar-vm-fisica").trigger("click")     
            document.querySelector(".loader").classList.add("loader-hide")
            document.querySelector(".status_text").classList.add("status_text-hide")
        }else{
            $("#formdoip")[0].value = msg.ip
            document.querySelector(".loader").classList.add("loader-hide")
            document.querySelector(".status_text").classList.add("status_text-hide")
        }
    },2000)
    
})


socket.on("created", async function (msg) {
    if (msg.fisica){
        $("#formdasenha-fisica")[0].value=msg.password
        $("#formdoip-fisica")[0].value = msg.ip
        $("#entrar-vm-fisica").trigger("click")     
        document.querySelector(".loader").classList.add("loader-hide")
        document.querySelector(".status_text").classList.add("status_text-hide")
    }else{
        $("#formdoip")[0].value = msg.ip
        document.querySelector(".loader").classList.add("loader-hide")
        document.querySelector(".status_text").classList.add("status_text-hide")
    }
})




socket.on("changePage", async function (msg) {

})





let vm = ''


function changePage() {
    let t = game

    if (game == "gtav") {
        t = (`gtav-${launcher}`)
    }


    if (game == "rleague") {
        t = (`rleague-${launcher}`)
    }

    const vmType = document.querySelector('input[name="machine-type"]:checked').id;
    parteCriar()

    tryLaunch(t, vmType)
}


function checarAssinatura() {
    socket.emit("checarAssinatura", '')

    parteCriar()
    document.getElementById("status_text").innerHTML = `Checando assinatura...`
    /*document.getElementsByTagName('body')[0].style.background = ""
    document.getElementsByTagName('body')[0].style.backgroundImage = "url('https://play.brightcloudgames.com.br/images/vip_loading21.jpg')";
    document.getElementsByTagName('body')[0].style.backgroundSize = "cover"
    document.getElementsByTagName('body')[0].style.backgroundRepeat = "no-repeat"*/

    socket.on("assinatura", async function (msg) {
        if (msg == true) {
            fisicaLaunch()
        } else {
            window.location.href = '/'
        }
    })
}


function fisicaLaunch() {
    document.getElementsByClassName("btn btn-hover")[1].classList.remove("btn-hover--hidden")
    //document.querySelector(".loader").classList.remove("loader--hidden")



    socket.emit("choose", "fisica")
    socket.emit("vmCommand", { "event": "List" })

    document.getElementById("status_text").innerHTML = `Carregando sua VM Física...`




    // document.querySelector(".iframe").classList.remove("iframe--hidden")
}



function tryLaunch(game, vmType) {
    if (vmType == "google") {


        socket.emit("choose", "google")







        socket.on("vms", async function (msg) {
            console.log(msg[0])
            socket.emit("vmCommand", { "event": "CreateVM", "game": game })
        })

        socket.on("status", async function (msg) {
            document.getElementById("status_text").innerHTML = msg
        })

        socket.on("error", async function (msg) {
            console.log("ERROR")

            window.location.href = "/"

        })



        socket.emit("vmCommand", { "event": "List" })

    } else if (vmType == "azure") {


        socket.emit("choose", "azure")



        socket.on("vms", async function (msg) {
            console.log(msg[0])
            socket.emit("vmCommand", { "event": "CreateVM", "game": game })
        })

        socket.on("status", async function (msg) {
            document.getElementById("status_text").innerHTML = msg
        })

        socket.on("error", async function (msg) {
            console.log("ERROR")

            window.location.href = "/"

        })


        socket.emit("vmCommand", { "event": "List" })
    }
}
